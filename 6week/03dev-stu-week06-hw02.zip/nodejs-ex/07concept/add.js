// ./concept/add.js
var add = function (a, b) {
    return a + b;
}
var result = add(4, 2);
console.log('더하기(4,2): %d', result);