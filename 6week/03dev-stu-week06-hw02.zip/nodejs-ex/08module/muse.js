// ./module/muse.js
var part = require('./mpart.js');
part.f();